// script.js
document.addEventListener('DOMContentLoaded', () => {
    const board = document.getElementById('board');
    const cells = document.querySelectorAll('.cell');
    const restartButton = document.getElementById('restartButton');
    const winMessage = document.getElementById('winMessage');
    const winMessageText = document.getElementById('winMessageText');
    const playAgainButton = document.getElementById('playAgainButton');
    let currentPlayer = 'X';
    let gameState = Array(9).fill(null);
    let gameActive = true;

    const winningConditions = [
        [0, 1, 2],
        [3, 4, 5],
        [6, 7, 8],
        [0, 3, 6],
        [1, 4, 7],
        [2, 5, 8],
        [0, 4, 8],
        [2, 4, 6]
    ];

    const checkWinner = () => {
        for (let condition of winningConditions) {
            const [a, b, c] = condition;
            if (gameState[a] && gameState[a] === gameState[b] && gameState[a] === gameState[c]) {
                return gameState[a];
            }
        }
        return gameState.includes(null) ? null : 'Tie';
    };

    const handleClick = (event) => {
        const cell = event.target;
        const index = parseInt(cell.getAttribute('data-index'));

        if (gameState[index] || !gameActive) return;

        gameState[index] = currentPlayer;
        cell.textContent = currentPlayer;

        const winner = checkWinner();

        if (winner) {
            gameActive = false;
            winMessageText.textContent = winner === 'Tie' ? "It's a tie!" : `${winner} wins!`;
            winMessage.classList.add('active');
        } else {
            currentPlayer = currentPlayer === 'X' ? 'O' : 'X';
        }
    };

    const restartGame = () => {
        currentPlayer = 'X';
        gameState = Array(9).fill(null);
        gameActive = true;
        cells.forEach(cell => cell.textContent = '');
        winMessage.classList.remove('active');
    };

    cells.forEach(cell => cell.addEventListener('click', handleClick));
    restartButton.addEventListener('click', restartGame);
    playAgainButton.addEventListener('click', restartGame);
});
